package com.example.morse_vibration_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
