import 'package:flutter/material.dart';
import 'package:vibration/vibration.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

void main() {
  runApp(const MorseVibrationApp());
}

class MorseVibrationApp extends StatelessWidget {
  const MorseVibrationApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Morse Code Vibration',
      debugShowCheckedModeBanner: false,
      theme: ThemeData.light().copyWith(
        primaryColor: Colors.blueAccent,
        scaffoldBackgroundColor: Colors.white,
      ),
      home: const MorseCodeScreen(),
    );
  }
}

class MorseCodeScreen extends StatefulWidget {
  const MorseCodeScreen({super.key});

  @override
  State<MorseCodeScreen> createState() => _MorseCodeScreenState();
}

class _MorseCodeScreenState extends State<MorseCodeScreen> {
  final TextEditingController _textController = TextEditingController();
  String _morseCode = "";

  Future<void> _convertAndVibrate() async {
    final text = _textController.text.trim();
    if (text.isEmpty) return;

    try {
      final response = await http.post(
        Uri.parse('http://192.168.203.33:5000/morse'), // Replace with your PC's IP
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({'text': text}),
      );

      if (response.statusCode == 200) {
        final morse = jsonDecode(response.body)['morse'];
        setState(() => _morseCode = morse);
        _vibrateMorse(morse);
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text("Morse Code: $morse")),
        );
      } else {
        throw Exception("Failed to get Morse code");
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Error: $e")),
      );
    }
  }

  Future<void> _vibrateMorse(String morse) async {
    List<int> pattern = [];
    int dotDuration = 200;
    int dashDuration = 600;
    int gapBetweenSymbols = 200;

    for (var symbol in morse.split('')) {
      if (symbol == '.') {
        pattern.add(dotDuration);
      } else if (symbol == '_') {
        pattern.add(dashDuration);
      }
      pattern.add(gapBetweenSymbols);
    }

    if (await Vibration.hasVibrator() ?? false) {
      Vibration.vibrate(pattern: pattern);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Morse Code Vibration"),
        backgroundColor: Colors.blueAccent,
      ),
      body: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Text(
              "Enter text to convert into Morse Code and feel vibrations:",
              textAlign: TextAlign.center,
              style: TextStyle(fontSize: 18),
            ),
            const SizedBox(height: 20),
            TextField(
              controller: _textController,
              decoration: const InputDecoration(
                border: OutlineInputBorder(),
                labelText: "Enter text",
              ),
            ),
            const SizedBox(height: 20),
            ElevatedButton(
              onPressed: _convertAndVibrate,
              child: const Text("Convert & Vibrate"),
            ),
            const SizedBox(height: 20),
            if (_morseCode.isNotEmpty)
              Text("Morse: $_morseCode", style: TextStyle(fontSize: 16)),
          ],
        ),
      ),
    );
  }
}
